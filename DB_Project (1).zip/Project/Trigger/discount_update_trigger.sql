create or replace TRIGGER Discount_Update

  AFTER INSERT ON CUSTOMER
  FOR EACH ROW
  DECLARE user_rew VARCHAR(50);
    
BEGIN
    IF(:NEW.EMAIL_ID = '' OR :NEW.EMAIL_ID is null) THEN
        dbms_output.put('Please eneter email_id for new customer');
    END IF;
    user_rew:=:NEW.EMAIL_ID;
    user_rew:=concat(user_rew,'NEW_CUST_DISC');
    INSERT INTO REWARDS(discount_code,referal,discount_amount,customer_email_id) values(user_rew,null,4.99,:NEW.EMAIL_ID);
    dbms_output.put('Ride discount added for new customer Successfully');

END;