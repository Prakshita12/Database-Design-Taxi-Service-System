create or replace TRIGGER RIDE_INFO_INSERT
AFTER INSERT
  ON RIDE
  FOR EACH ROW
  DECLARE 
  ride_count number(38,0);
  rating_old float;
  rating_new float;
BEGIN
    select rides,rating
    into ride_count,rating_old
    from driver
    where :new.driver_email_id=email_id;
    rating_new:=((rating_old*ride_count)+:new.rating)/(ride_count+1);
    ride_count:=ride_count+1;
    update driver set rating=rating_new
    where :new.driver_email_id=email_id;
    
   dbms_output.put('RIDE_INFO Inserted Successfully');
  END;